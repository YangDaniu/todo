// // We need this to build our post string

const http = require('http');

const FormData = require('form-data');
const fs = require('fs');
const glob = require("glob")

const cssCdnPath = 'cssn/newsapp/cyshare/'
const jsCdnPath = 'js/newsapp/cyshare/'
const cookie = "PAS_COOKIE_TICKET=82f0b601aeff3ce4;PAS_COOKIE_USER=aiyang;PAS_COOKIE_SITENAME=www;PAS_COOKIE_PROJECT_AUTO=%u5185%u5BB9%u7BA1%u7406%u7CFB%u7EDF-%u817E%u8BAF%u9996%u9875%7Chttp%3A//wizard2.webdev.com/tcms/%7Cwww;PAS_COOKIE_PROJECT_GROUP=|||TCMS:www:腾讯首页|;sitename=www";


function postFile(file, cdnPath){
    const form = new FormData();
    form.append('upfile', fs.createReadStream(file));
    form.append('newname', '');
    form.append('overwrite', '1');
    form.append('addmat', '1');
    form.append('watermark', '0');
    form.append('defaultwater', '0');
    form.append('url', 'http://wizard2.webdev.com/cgi-bin/material/material_list?dir=' + cdnPath);
    form.append('path', cdnPath);
    const options = {
        protocol: 'http:',
        // host: '10.22.110.58',
        // port: '8888',
        // path: 'http://wizard2.webdev.com/cgi-bin/material/material_add',
        host: 'wizard2.webdev.com',
        path: '/cgi-bin/material/material_add',
        method: 'post',
        headers: {
            'content-type': form.getHeaders()['content-type'],
            'Cookie': encodeURI(cookie)
        }
    };
    
    const request = http.request(options);
    
    form.pipe(request);
    request.on('response', function (res) {
        res.on('data', function(chunk) {
            // do what you do
            process.stdout.write(chunk);
        });
        res.on('end', function() {
            // do what you do
            console.log(arguments)
        });
    });
}




glob("./release/*.js", function (er, files) {
 // files is an array of filenames. 
 // If the `nonull` option is set, and nothing 
 // was found, then files is ["**/*.js"] 
 // er is an error object or null. 
    console.log(files)
    files.forEach((val, key) => {
        postFile(val, jsCdnPath)
    })
})

glob("./release/*.css", function (er, files) {
    // files is an array of filenames. 
    // If the `nonull` option is set, and nothing 
    // was found, then files is ["**/*.js"] 
    // er is an error object or null. 
       console.log(files)
       files.forEach((val, key) => {
           postFile(val, cssCdnPath)
       })
   })